# 의대교육혁신사업 성과 홈페이지

주소: https://medahn-cmd.github.io/innovation/

기존 루트의 지역사회기반 교육과정 입력 양식은 그대로 유지합니다.

## 페이지 구조

- `index.html`: 일러스트 과제 지도, 전체 과제 목록
- `projects/{id}/index.html`: 과제 개요
- `projects/{id}/activities/index.html`: 추진 내용
- `projects/{id}/outcomes/index.html`: 주요 성과
- `projects/{id}/resources/index.html`: 결과 자료
- `projects/{id}/{section}/{item-id}/index.html`: 개별 세부 내용
- `about/index.html`: 사업 소개 및 공개 안내

여기서 가지(Branch)는 웹사이트의 계층형 하위 페이지를 뜻하며, Git 브랜치를 여러 개 만들 필요가 없습니다. 모든 페이지는 직접 주소 접근, 새로고침 및 JavaScript 비활성 상태에서도 열립니다.

## 추후 자료 일괄 반영

현재 6개 과제명은 가상의 성과가 아닌, 명시적으로 표시된 임시 분류입니다. 실제 과제 수는 제한하지 않습니다.

1. `data/projects.json`의 `projects` 배열을 실제 과제 목록으로 교체합니다. 기존 공개 주소를 유지하려면 `id`를 유지합니다.
2. 항목마다 `title`, `summary`, `overview`, `department`, `period`, `goal`을 입력합니다.
3. `activities`, `outcomes`, `resources`에 세부 항목을 추가합니다. 항목 형식은 아래 예시를 사용합니다.
4. PDF와 이미지 등은 `files/` 아래에 넣고, 공개 가능한 파일만 포함합니다.
5. 저장소 루트에서 `node innovation/build.mjs` 실행 후 생성된 HTML과 자료를 함께 커밋하면 기존 GitHub Pages 배포가 실행됩니다. 별도 패키지 설치가 필요 없습니다.
6. 실제 자료 공개 시 홈페이지·사업 소개·과제 페이지의 임시 안내 문구를 공식 내용으로 교체합니다. 현재는 공개 자료가 없기 때문에 안내를 유지합니다.

```json
{
  "id": "activity-01",
  "title": "세부 활동의 공식 명칭",
  "summary": "한두 문장 요약",
  "body": ["첫 번째 문단", "두 번째 문단"],
  "attachments": [
    {"title": "결과 보고서 PDF", "url": "files/project-01/report.pdf"}
  ]
}
```

과제 및 세부 항목 ID는 영문 소문자·숫자·하이픈만 사용합니다. 외부 첨부 주소는 `https://`로 시작해야 합니다. 본문은 일반 텍스트로 처리하여 HTML이 실행되지 않습니다. 첨부 파일은 임의 실행 업로드 기능 대신 검토된 정적 자료로 게시됩니다. 파일 업로드 화면이나 비공개 데이터베이스는 이번 사전 구축 범위에 포함하지 않습니다.

## 관리

`node innovation/validate.mjs`로 생성된 모든 HTML의 내부 링크, 자산 참조와 문서 제목을 확인합니다. 과제를 삭제하거나 ID를 바꾼 경우 사용하지 않는 기존 하위 경로는 담당자가 확인 후 정리해야 합니다. 생성기는 안전상 기존 디렉터리를 자동 삭제하지 않습니다.

## 일러스트

`assets/campus.png`: 내장 image_gen으로 생성한 1536×1024 개념 일러스트. 실제 시설을 나타내지 않습니다.

Prompt: A polished isometric medical education innovation campus, central medical teaching building connected by paths to six distinct learning areas: classroom with books, clinical simulation mannequin, teacher seminar, digital learning workstations, student collaboration and community health center. Wide 1536×1024, white/icy blue background, navy/blue/turquoise and small orange accents, soft 3D architectural illustration, generous space, no words, labels, numbers, logos, or UI. Conceptual art, not real facilities.
