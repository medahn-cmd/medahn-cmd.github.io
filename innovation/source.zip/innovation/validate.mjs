import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const walk=d=>fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(d,e.name)):[path.join(d,e.name)]);
const htmls=walk(root).filter(f=>f.endsWith('.html'));let links=0;
for(const file of htmls){const text=fs.readFileSync(file,'utf8');assert(text.includes('<html lang="ko">'));assert.equal((text.match(/<h1[ >]/g)||[]).length,1,file);assert(/<title>[^<]+<\/title>/.test(text));for(const match of text.matchAll(/(?:href|src)="([^"]+)"/g)){const href=match[1];if(/^(https?:|mailto:|data:)/.test(href))continue;const [url,hash]=href.split('#');let target=path.resolve(path.dirname(file),decodeURIComponent(url||'.'));if(!url)target=file;assert(target.startsWith(root+path.sep)||target===root,'Outside site: '+href);assert(fs.existsSync(target),'Missing '+href+' from '+file);if(fs.statSync(target).isDirectory())target=path.join(target,'index.html');assert(fs.existsSync(target),'Missing index: '+target);if(hash){assert(fs.readFileSync(target,'utf8').includes('id="'+hash+'"'),'Missing anchor: '+href);}links++;}}
console.log(`PASS: ${htmls.length} HTML pages; ${links} local links/assets; Korean language, unique primary heading and titles.`);
